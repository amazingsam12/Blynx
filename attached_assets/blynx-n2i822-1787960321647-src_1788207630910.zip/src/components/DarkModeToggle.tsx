import { useEffect, useState } from 'react';

const STORAGE_KEY = 'blynx-theme';

export default function DarkModeToggle() {
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem(STORAGE_KEY) === 'dark');

  useEffect(() => {
    document.documentElement.dataset.theme = darkMode ? 'dark' : 'light';
    localStorage.setItem(STORAGE_KEY, darkMode ? 'dark' : 'light');
  }, [darkMode]);

  return <label className='toggle-setting'><span><strong>Dark Mode</strong><small>{darkMode ? 'Dark theme is on.' : 'Use the light theme.'}</small></span><button type='button' role='switch' aria-checked={darkMode} className={darkMode ? 'toggle-switch on' : 'toggle-switch'} onClick={() => setDarkMode(value => !value)}><span /></button></label>;
}
