import { useEffect, useMemo, useState } from 'react';
import { ChevronLeft, Edit3, MessageCircle, Send, UserPlus, Trash2, MapPin, Phone, UserRound } from 'lucide-react';
import { api } from '../lib/api';
import EditProfileModal from './EditProfileModal';


type Props = {
  role?: string | null;
  profile?: any;
  userId?: string | null;
  publicBusinessId?: string | null;
  onSettings?: () => void;
  onSignOut?: () => void;
  onBack: () => void;
  onMessage?: (id: string) => void;
};

export default function PolishedProfile({ role, profile: initialProfile, userId, publicBusinessId, onSettings, onSignOut, onBack, onMessage }: Props) {
  const targetId = String(userId || publicBusinessId || initialProfile?.id || '');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [tab, setTab] = useState<'posts' | 'about' | 'reviews'>('posts');
  const [editOpen, setEditOpen] = useState(false);
  const [following, setFollowing] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);

  useEffect(() => {
    let alive = true;
    const loadCurrentUser = async () => {
      try {
        const r = await api.get('/api/me');
        if (alive) setCurrentUser(r.data?.user || r.data?.profile || null);
      } catch {}
    };
    void loadCurrentUser();
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    let alive = true;
    const loadProfile = async () => {
      if (!targetId) {
        if (alive) { setError('No user ID provided'); setLoading(false); }
        return;
      }
      setLoading(true);
      setError('');
      setData(null);
      const requestedRole = String(role || '').toLowerCase();
      const endpoints = requestedRole === 'customer'
        ? ['/api/customer/me']
        : requestedRole === 'rider'
          ? [`/api/rider/${encodeURIComponent(targetId)}/public`]
          : requestedRole === 'business'
            ? [`/api/business/${encodeURIComponent(targetId)}/public`]
            : [
                `/api/business/${encodeURIComponent(targetId)}/public`,
                `/api/rider/${encodeURIComponent(targetId)}/public`,
                '/api/customer/me'
              ];
      for (const endpoint of endpoints) {
        try {
          const r = await api.get(endpoint);
          const body = r.data || {};
          const found = body.business || body.rider || body.profile;
          if (!found) continue;
          const detectedRole = String(body.role || found.role || requestedRole || 'customer').toLowerCase();
          if (detectedRole === 'customer' && String(found.id) !== targetId) continue;
          if (alive) {
            setData({ ...body, profile: found, role: detectedRole });
            setFollowing(Boolean(body.following));
            setLoading(false);
          }
          return;
        } catch {}
      }
      if (alive) { setError('Could not load profile. Please try again.'); setLoading(false); }
    };
    void loadProfile();
    return () => { alive = false; };
  }, [targetId, role]);

  const p = data?.business || data?.rider || data?.profile || initialProfile || null;
  const effectiveRole = String(data?.role || role || p?.role || 'customer').toLowerCase();
  const isOwner = Boolean(currentUser?.id && p?.id && String(currentUser.id) === String(p.id)) || (!userId && !publicBusinessId && Boolean(initialProfile?.id));
  const posts = useMemo(() => {
    if (effectiveRole === 'customer') return data?.customer_posts || [];
    return data?.posts || [];
  }, [data, effectiveRole]);
  const reviews = data?.reviews || [];
  const initials = String(p?.name || 'User').split(/\s+/).map((x: string) => x[0]).join('').slice(0, 2).toUpperCase();

  const follow = async () => {
    if (!currentUser || !p?.id) return;
    try {
      const r = await api.post('/api/follow', { userId: String(p.id) });
      setFollowing(Boolean(r.data?.following));
    } catch {}
  };

  const message = () => {
    if (p?.id && onMessage) onMessage(String(p.id));
  };

  const share = () => {
    if (navigator.share) void navigator.share({ title: p?.name || 'Blynx Profile', url: window.location.href });
    else void navigator.clipboard?.writeText(window.location.href);
  };

  const deletePost = async (id: string) => {
    if (!window.confirm('Delete this post?')) return;
    try {
      await api.delete('/api/posts/' + id);
      setData((d: any) => ({ ...d, posts: (d?.posts || []).filter((x: any) => String(x.id) !== String(id)) }));
    } catch {}
  };

  if (loading) return <div className='empty-state'><UserRound size={34} /><h3>Loading profile...</h3></div>;
  if (error || !p) return <div className='empty-state'><UserRound size={34} /><h3>{error || 'Could not load profile. Please try again.'}</h3><button className='secondary' onClick={onBack}>Go back</button></div>;

  return (
    <section className='profile-page-polished'>
      <button className='back-btn' onClick={onBack} aria-label='Back'><ChevronLeft size={24} /></button>
      <div className='profile-cover' style={p.cover_photo_url ? { backgroundImage: `url(${p.cover_photo_url})`, backgroundSize: 'cover', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' } : {}} />
      <div className='profile-avatar-overlap'>
        <div className='profile-avatar-polished'>
          {p.avatar_url ? <img src={p.avatar_url} alt='Avatar' className='avatar-image' /> : <span>{initials}</span>}
        </div>
      </div>
      <section className='profile-info-polished'>
        <h1>{p.name || 'User'}</h1>
        <p className='profile-role-polished'>{effectiveRole === 'business' ? 'Business' : effectiveRole === 'rider' ? 'Rider' : 'Customer'}</p>
        <p>{p.bio || 'No bio added yet'}</p>
        <small>Joined {p.joined_date ? new Date(p.joined_date).toLocaleDateString(undefined, { month: 'long', year: 'numeric' }) : 'recently'}</small>
        {(effectiveRole === 'business' || effectiveRole === 'rider') && (
          <div className='profile-stats-polished'>
            <button><b>{Number(p.following_count || 0)}</b><span>Following</span></button>
            <button><b>{Number(p.followers_count || 0)}</b><span>Followers</span></button>
            <button onClick={() => setTab('reviews')}><b>{reviews.length}</b><span>Reviews</span></button>
          </div>
        )}
      </section>
      <div className='profile-actions-polished'>
        {isOwner ? (
          <>
            <button className='profile-outline-btn' onClick={() => setEditOpen(true)}><Edit3 size={16} /> Edit Profile</button>
            <button className='profile-outline-btn' onClick={share}><Send size={16} /> Share</button>
          </>
        ) : effectiveRole === 'business' || effectiveRole === 'rider' ? (
          <>
            <button className='profile-primary-btn' onClick={message}><MessageCircle size={16} /> Message</button>
            <button className='profile-outline-btn' onClick={() => void follow()}><UserPlus size={16} />{following ? 'Unfollow' : 'Follow'}</button>
            <button className='profile-outline-btn' onClick={share}><Send size={16} /> Share</button>
          </>
        ) : (
          <button className='profile-outline-btn' onClick={share}><Send size={16} /> Share</button>
        )}
      </div>
      <nav className='profile-tabs-polished'>
        <button className={tab === 'posts' ? 'active' : ''} onClick={() => setTab('posts')}>Posts</button>
        <button className={tab === 'about' ? 'active' : ''} onClick={() => setTab('about')}>About</button>
        <button className={tab === 'reviews' ? 'active' : ''} onClick={() => setTab('reviews')}>Reviews</button>
      </nav>
      <div className='profile-tab-content'>
        {tab === 'posts' && (
          posts.length ? <div className='profile-post-feed'>{posts.map((post: any) => {
            const media = Array.isArray(post.media) && post.media.length ? post.media : Array.isArray(post.mediaUrls) ? post.mediaUrls : (post.image ? [post.image] : []);
            return (
              <article className='post-card' key={post.id}>
                <div className='post-head'>
                  <div className='post-author'>
                    <span className='post-avatar'>{post.avatarUrl || p.avatar_url ? <img src={post.avatarUrl || p.avatar_url} alt='' className='avatar-img' /> : <span>{post.initials || initials}</span>}</span>
                    <div><b>{post.business || post.authorName || p.name || 'User'}</b><small>{post.time || (post.createdAt ? new Date(post.createdAt).toLocaleDateString() : 'now')}</small></div>
                  </div>
                  {isOwner && effectiveRole !== 'customer' && <button className='icon-btn' onClick={() => void deletePost(String(post.id))} aria-label='Delete post'><Trash2 size={17} /></button>}
                </div>
                {(post.caption || post.content) && <p className='post-caption'>{post.caption || post.content}</p>}
                {media.length > 0 && <div className='post-image-wrapper'>{media.map((item: any, index: number) => { const url = typeof item === 'string' ? item : String(item?.url || item?.media_url || ''); const type = item?.type || (/\.(mp4|mov|webm|avi|m4v)(\?|$)/i.test(url) ? 'video' : 'image'); return type === 'video' ? <video key={index} src={url} controls className='post-video' preload='metadata' playsInline style={{ display: 'block', width: '100%' }} /> : <img key={index} src={url} alt={'Post ' + (index + 1)} className='post-image' loading='lazy' style={{ display: 'block', width: '100%' }} />; })}</div>}
                <div className='post-actions'><span>❤️ {Number(post.likes || 0)}</span><span>💬 {Number(post.commentCount || post.comments || 0)}</span></div>
              </article>
            );
          })}</div> : <div className='empty-state'>No posts yet</div>
        )}
        {tab === 'about' && <div className='profile-about notice'><div><b>About</b><p>{p.bio || 'No bio added yet'}</p><p><MapPin size={15} /> {p.location || p.address || 'Location not added'}</p>{p.phone && <p><Phone size={15} /> {p.phone}</p>}</div></div>}
        {tab === 'reviews' && (reviews.length ? reviews.map((x: any) => <article className='notice' key={x.id}><div><b>{x.reviewerName || 'Customer'}</b><p>{'★'.repeat(Number(x.rating || 0))} {x.comment || 'No comment'}</p></div></article>) : <div className='empty-state'>No reviews yet</div>)}
      </div>
      {editOpen && <EditProfileModal role={effectiveRole} profile={p} onClose={() => setEditOpen(false)} onSaved={() => window.location.reload()} />}
    </section>
  );
}
