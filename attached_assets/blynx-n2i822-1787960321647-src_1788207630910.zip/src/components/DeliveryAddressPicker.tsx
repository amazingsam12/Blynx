import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

type Point = { latitude: number; longitude: number };

export default function DeliveryAddressPicker({ value, onChange, addressLabel }: { value: Point | null; onChange: (point: Point) => void; addressLabel: string }) {
  const mapEl = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  useEffect(() => {
    if (!mapEl.current || mapRef.current) return;
    const fallback: [number, number] = [6.5244, 3.3792];
    const initial: [number, number] = value ? [value.latitude, value.longitude] : fallback;
    const map = L.map(mapEl.current, { zoomControl: true, scrollWheelZoom: true }).setView(initial, value ? 16 : 12);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; OpenStreetMap contributors' }).addTo(map);
    const marker = L.marker(initial, { draggable: true }).addTo(map);
    marker.bindPopup('<strong>Delivery entrance</strong><br>Drag the pin to the exact entrance.').openPopup();
    marker.on('dragend', () => { const position = marker.getLatLng(); onChange({ latitude: position.lat, longitude: position.lng }); });
    mapRef.current = map; markerRef.current = marker;
    const timer = window.setTimeout(() => map.invalidateSize(), 100);
    return () => { window.clearTimeout(timer); map.remove(); mapRef.current = null; markerRef.current = null; };
  }, []);
  useEffect(() => {
    const map = mapRef.current; const marker = markerRef.current; if (!map || !marker || !value) return;
    const point: [number, number] = [value.latitude, value.longitude]; marker.setLatLng(point); map.setView(point, Math.max(map.getZoom(), 15));
  }, [value]);
  return <section className='delivery-address-map'><div className='profile-section-heading'><div><span className='eyebrow'>EXACT ENTRANCE</span><h3>Adjust your delivery pin</h3></div><span>{addressLabel || 'Choose your entrance'}</span></div><p className='muted'>Drag the pin to the building entrance where the rider should meet you.</p><div ref={mapEl} style={{ width: '100%', height: 260, borderRadius: 16, overflow: 'hidden' }} aria-label='Draggable delivery location map'/></section>;
}
