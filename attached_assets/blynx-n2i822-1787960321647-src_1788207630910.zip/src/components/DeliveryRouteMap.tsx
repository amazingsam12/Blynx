import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

type Point={latitude:number;longitude:number};

export default function DeliveryRouteMap({pickup,dropoff,pickupLabel,dropoffLabel}:{pickup:Point;dropoff:Point;pickupLabel:string;dropoffLabel:string}){
 const mapEl=useRef<HTMLDivElement>(null);const mapRef=useRef<L.Map|null>(null);
 useEffect(()=>{if(!mapEl.current||mapRef.current)return;const map=L.map(mapEl.current,{zoomControl:true,scrollWheelZoom:true});L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'&copy; OpenStreetMap contributors'}).addTo(map);const pickupMarker=L.marker([pickup.latitude,pickup.longitude]).addTo(map).bindPopup('<strong>Pickup</strong><br>'+pickupLabel.replace(/</g,'&lt;'));const dropMarker=L.marker([dropoff.latitude,dropoff.longitude]).addTo(map).bindPopup('<strong>Delivery</strong><br>'+dropoffLabel);const line=L.polyline([[pickup.latitude,pickup.longitude],[dropoff.latitude,dropoff.longitude]]).addTo(map);map.fitBounds(L.latLngBounds([[pickup.latitude,pickup.longitude],[dropoff.latitude,dropoff.longitude]]),{padding:[35,35],maxZoom:15});pickupMarker.openPopup();mapRef.current=map;const timer=window.setTimeout(()=>map.invalidateSize(),100);return()=>{window.clearTimeout(timer);line.remove();pickupMarker.remove();dropMarker.remove();map.remove();mapRef.current=null;};},[pickup.latitude,pickup.longitude,dropoff.latitude,dropoff.longitude,pickupLabel,dropoffLabel]);return <div className='delivery-address-map'><div className='profile-section-heading'><div><span className='eyebrow'>ROUTE MAP</span><h3>Pickup & delivery</h3></div><span>Pickup • Delivery</span></div><div ref={mapEl} style={{width:'100%',height:300,borderRadius:16,overflow:'hidden'}}/></div>;
}